package com.movies.moviesapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MoviesAppApplicationTests {

    @Test
    void contextLoads() {
    }

}
